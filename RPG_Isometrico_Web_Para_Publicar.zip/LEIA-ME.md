# Prévia Web — RPG Isométrico Etapa 16

Este `index.html` é a demonstração Canvas/JavaScript jogável com a mesma pixel art da Etapa 16 Godot. **Não é o motor Godot exportado.**

Para publicar: envie `index.html` à raiz de um repositório GitHub Pages, habilite Pages em Settings → Pages, e mantenha o mesmo endereço ao atualizar.

Quando o projeto Godot puder ser exportado, substitua esta prévia por **todos** os arquivos da build Web do Godot.
